<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale-1.0">
    <title>Худенко А.А.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css” />
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<main>
    <div class="login">
        <h1>Вход</h1>
        <div class="login_form">
            <div class="col-12">
                <form method="POST" action="/login.php">
                    <div class="form_reg"><input type="text" class="form"  name="username" placeholder="Login"></div>
                    <div class="form_reg"><input type="password" class="form"  name="password" placeholder="Password"></div>
                    <button class="btn_reg" type="submit" name="submit">Продолжить</button>
                </form>
            </div>
        </div>
    </div>
</main> 
</body>
</html>


<?php
#    require_once('db.php');

    $link = mysqli_connect('127.0.0.1', 'root', 'kali', 'first');
    
    if (isset($_COOKIE['User'])) {
        header("Location: profile.php");
    }
    
    if (isset($_POST['submit'])) {

        $title = mysqli_real_escape_string($link, $_POST['title']);
        $main_text = mysqli_real_escape_string($link, $_POST['text']);
    
        if (!$title || !$main_text) die("Заполните все поля");
    
        $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $main_text = htmlspecialchars($main_text, ENT_QUOTES, 'UTF-8');
    
        $sql = "INSERT INTO posts (title, main_text) VALUES ('$title', '$main_text')";
    
        if(!mysqli_query($link, $sql)) die("не удалось добавить пост");
    }

        if(!mysqli_query($link, $sql)) {
            echo "Не удалось найти пользователя";
        }

?>